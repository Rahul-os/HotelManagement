export class Hotel {
    constructor(
        public hotelId: number,
        public licenceNumber: string,
        public hotelName: string,
        public hotelAddress: string,
        public hotelContactNumber: string,
        public hotelImageURL: string,

    ) { }
}
