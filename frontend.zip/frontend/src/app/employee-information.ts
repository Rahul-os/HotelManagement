export class Employee {
    constructor(
        public employeeId: number,
        public hotelName: string,
        public licenceNumber: string,
        public hotelId: number,
        public name: string,
        public email: string,
        public password: string,
        public address: string,
        public contactNumber: string,
        public nationality: string
    ) { }
} 
