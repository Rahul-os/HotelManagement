import { LocationSearchPipe } from './location-search.pipe';

describe('LocationSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new LocationSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
